﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace SeaBattle
{
    public partial class Form1 : Form
    {
        private DataGridView dgvPlayer;
        private DataGridView dgvEnemy;
        private Label lblStatus;
        private GameController game;

        public Form1()
        {
            InitializeComponent();
            InitializeUI();
            StartNewGame();
        }

        private void Form1_Load(object sender, EventArgs e) { }

        private void InitializeUI()
        {
            this.Text = "Морской Бой (ООП C#)";
            this.Size = new Size(880, 520);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.FromArgb(240, 240, 240);

            dgvPlayer = CreateGrid("ВАШЕ ПОЛЕ", 30, 60, false);
            dgvEnemy = CreateGrid("ПОЛЕ ПРОТИВНИКА", 450, 60, true);
            dgvEnemy.CellClick += DgvEnemy_CellClick;

            lblStatus = new Label
            {
                Location = new Point(30, 440),
                Size = new Size(820, 40),
                Font = new Font("Arial", 12, FontStyle.Bold),
                ForeColor = Color.DarkBlue,
                Text = "Ваш ход! Кликните по полю компьютера."
            };
            this.Controls.Add(lblStatus);
        }

        private DataGridView CreateGrid(string title, int x, int y, bool isEnemy)
        {
            Label lblTitle = new Label
            {
                Text = title,
                Location = new Point(x, y - 25),
                Font = new Font("Arial", 11, FontStyle.Bold),
                ForeColor = Color.DarkSlateGray
            };
            this.Controls.Add(lblTitle);

            DataGridView dgv = new DataGridView
            {
                Location = new Point(x, y),
                Size = new Size(400, 360),
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.CellSelect,
                RowHeadersVisible = false,
                ColumnHeadersVisible = false,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.FixedSingle,
                EnableHeadersVisualStyles = false
            };

            dgv.ColumnHeadersDefaultCellStyle.BackColor = Color.LightGray;
            dgv.RowHeadersDefaultCellStyle.BackColor = Color.LightGray;

            for (int i = 0; i < 10; i++)
            {
                dgv.Columns.Add(new DataGridViewTextBoxColumn
                {
                    Width = 38,
                    DefaultCellStyle = new DataGridViewCellStyle { Alignment = DataGridViewContentAlignment.MiddleCenter, Font = new Font("Arial", 14, FontStyle.Bold) }
                });
                dgv.Rows.Add();
                dgv.Rows[i].Height = 34;
            }

            this.Controls.Add(dgv);
            return dgv;
        }

        private void StartNewGame()
        {
            game = new GameController();

            game.OnGameMessage += (msg) => lblStatus.Text = msg;
            game.OnBoardUpdate += () => UpdateBoards();

            game.OnGameOver += (winner) =>
            {
                lblStatus.Text = $"Игра окончена! Победил: {winner}";
                lblStatus.ForeColor = winner == "Игрок" ? Color.Green : Color.Red;
                dgvEnemy.Enabled = false;

                if (MessageBox.Show("Начать новую игру?", "Игра окончена", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    lblStatus.ForeColor = Color.DarkBlue;
                    dgvEnemy.Enabled = true;
                    StartNewGame();
                }
            };

            UpdateBoards();
        }

        private void UpdateBoards()
        {
            UpdateGrid(dgvPlayer, game.Human.Board, showShips: true);
            UpdateGrid(dgvEnemy, game.Computer.Board, showShips: false);
        }

        private void UpdateGrid(DataGridView dgv, Board board, bool showShips)
        {
            for (int i = 0; i < Board.Size; i++)
            {
                for (int j = 0; j < Board.Size; j++)
                {
                    Cell cell = board.Grid[i, j];
                    DataGridViewCell dgvCell = dgv.Rows[j].Cells[i];

                    dgvCell.Style.ForeColor = Color.Black;

                    switch (cell.State)
                    {
                        case CellState.Empty:
                            dgvCell.Style.BackColor = Color.White;
                            dgvCell.Value = "";
                            break;
                        case CellState.Ship:
                            if (showShips)
                            {
                                dgvCell.Style.BackColor = Color.LightSkyBlue;
                                dgvCell.Value = "■";
                                dgvCell.Style.ForeColor = Color.DarkBlue;
                            }
                            else
                            {
                                dgvCell.Style.BackColor = Color.White;
                                dgvCell.Value = "";
                            }
                            break;
                        case CellState.Miss:
                            dgvCell.Style.BackColor = Color.FromArgb(230, 240, 255);
                            dgvCell.Value = "•";
                            dgvCell.Style.ForeColor = Color.Gray;
                            break;
                        case CellState.Hit:
                            dgvCell.Style.BackColor = Color.OrangeRed;
                            dgvCell.Value = "X";
                            dgvCell.Style.ForeColor = Color.White;
                            break;
                        case CellState.Killed:
                            dgvCell.Style.BackColor = Color.DarkRed;
                            dgvCell.Value = "X";
                            dgvCell.Style.ForeColor = Color.White;
                            break;
                    }
                }
            }
        }

        private void DgvEnemy_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex >= 0 && game.IsHumanTurn && !game.IsGameOver)
            {
                game.ProcessHumanShot(e.ColumnIndex, e.RowIndex);
            }
        }
    }
}