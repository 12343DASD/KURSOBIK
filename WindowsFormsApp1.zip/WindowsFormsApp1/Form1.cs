﻿using System;
using System.Drawing;
using System.Windows.Forms;
    

namespace RacingGame
{
    public partial class Form1 : Form
    {
        PictureBox player = new PictureBox();
        PictureBox enemy1 = new PictureBox();
        PictureBox enemy2 = new PictureBox();
        PictureBox enemy3 = new PictureBox();

        Timer timer = new Timer();
        Random rnd = new Random();

        int lane = 1;
        int score = 0;
        int speed = 8;

        public Form1()
        {
            InitializeComponent();

            Width = 500;
            Height = 700;
            Text = "Гонки";
            BackColor = Color.DarkGray;

            KeyPreview = true;

            player.Size = new Size(50, 90);
            player.BackColor = Color.Blue;
            player.Left = 200;
            player.Top = 550;

            enemy1.Size = new Size(50, 90);
            enemy2.Size = new Size(50, 90);
            enemy3.Size = new Size(50, 90);

            enemy1.BackColor = Color.Red;
            enemy2.BackColor = Color.Green;
            enemy3.BackColor = Color.Yellow;

            enemy1.Left = 100;
            enemy2.Left = 200;
            enemy3.Left = 300;

            enemy1.Top = -100;
            enemy2.Top = -300;
            enemy3.Top = -500;

            Controls.Add(player);
            Controls.Add(enemy1);
            Controls.Add(enemy2);
            Controls.Add(enemy3);

            timer.Interval = 30;
            timer.Tick += GameLoop;
            timer.Start();

            KeyDown += Form1_KeyDown;
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left && lane > 0)
            {
                lane--;
                player.Left = 100 + lane * 100;
            }

            if (e.KeyCode == Keys.Right && lane < 2)
            {
                lane++;
                player.Left = 100 + lane * 100;
            }
        }

        private void MoveEnemy(PictureBox enemy)
        {
            enemy.Top += speed;

            if (enemy.Top > Height)
            {
                enemy.Top = -100;
                enemy.Left = 100 + rnd.Next(3) * 100;

                score++;

                if (score % 10 == 0)
                    speed++;
            }
        }

        private void GameLoop(object sender, EventArgs e)
        {
            MoveEnemy(enemy1);
            MoveEnemy(enemy2);
            MoveEnemy(enemy3);

            if (player.Bounds.IntersectsWith(enemy1.Bounds) ||
            player.Bounds.IntersectsWith(enemy2.Bounds) ||
            player.Bounds.IntersectsWith(enemy3.Bounds))
            {
                timer.Stop();

                MessageBox.Show(
                $"Игра окончена!\nСчет: {score}",
                "Авария");

                Close();
            }
        }
    }
}